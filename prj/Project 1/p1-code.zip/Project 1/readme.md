CSCI4061 
Project 1
Carl Anderson & Andy Chen
and08571 & chen6640
